package useSocket;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	
	public static void main(String[] args) {
		
		Server server = new Server();
		server.serverCall();
		
	}
	
	
	public void serverCall() {
		try {
			
			// Port Permission
			ServerSocket serverSocket = new ServerSocket(9999);
			Socket sc = serverSocket.accept();
			
			
			InputStreamReader inputStreamReader = new InputStreamReader(sc.getInputStream());
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
			String message = "";
			PrintStream printStream = new PrintStream(sc.getOutputStream());
			while(true) {
				printStream.print("");
				message = bufferedReader.readLine().trim();
				if (message.equalsIgnoreCase("xxx")) break;
				System.out.println("Server : " + message);
				Scanner scanner = new Scanner(System.in);
				while(true) {
					printStream.print(scanner.next());
					break;
				}
				scanner.close();
			}
			
			//printStream.close();
			//bufferedReader.close();
			//sc.close();
			//serverSocket.close();
			
		} catch (Exception e) {
			System.err.println("Server Error : " + e);
		}
	}

}

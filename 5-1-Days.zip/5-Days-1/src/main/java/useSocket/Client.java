package useSocket;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

import org.aspectj.weaver.Dump.INode;

public class Client {

	public static void main(String[] args) {
		
		Client client = new Client();
		client.clientCall();
		
	}

	
	public void clientCall() {
		
		try {
			
			Socket socket = new Socket("localhost", 9999 );
			PrintStream printStream = new PrintStream(socket.getOutputStream());
			Scanner scanner = new Scanner(System.in);
			
			String message = "";
			InputStreamReader inputStreamReader = new InputStreamReader(socket.getInputStream());
			BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
			message = "Client Connection";
			printStream.println(message);
			
			while( !message.equalsIgnoreCase("ok") ) {
				message = scanner.nextLine();
				printStream.println(message);
				System.out.println("Server : " + bufferedReader.readLine().trim());
			}
			
			//printStream.close();
			//bufferedReader.close();
			//socket.close();
			
			
		} catch (Exception e) {
			System.err.println("Client Error : " + e);
		}
		
	}
	
}

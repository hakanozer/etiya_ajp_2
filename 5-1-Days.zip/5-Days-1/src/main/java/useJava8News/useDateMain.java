package useJava8News;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

public class useDateMain {

	public static void main(String[] args) {
		
		Date date = new Date();
		System.out.println(date.getHours());
		
		// LocalDateTime
		LocalDateTime now = LocalDateTime.now();
		System.out.println(now.getDayOfMonth());
		String dt = now.getDayOfMonth() + "-" + now.getMonthValue() + "-" + now.getYear();
		System.out.println(dt);

		// String format convet
		String pattern = "dd-MM-yyyy hh:mm:ss";
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		String stDate = dateFormat.format(new Date());
		System.out.println(new Date());
		System.out.println(stDate);
		
	}

}

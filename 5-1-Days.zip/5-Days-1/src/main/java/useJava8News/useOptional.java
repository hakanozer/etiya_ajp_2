package useJava8News;

import java.util.Optional;

public class useOptional {

	public static void main(String[] args) {
		
		Integer number = null;
		//number = 10;
		if ( number !=  null ) {
			System.out.println(number);
		}
		
		
		Optional<Integer> op1 = Optional.ofNullable(number);
		op1.ifPresent( item -> {
			System.out.println(item);
		});
		
		Integer newInt = op1.orElse(15);
		System.out.println(newInt);
		

	}

}

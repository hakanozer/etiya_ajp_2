package useJava8News;

import java.util.List;

public class MainStreamParalel {

	public static void main(String[] args) {
		
		Result rs = new Result();
		List<Result> ls = rs.data();
		
		
		// Stream Api
		ls
		.stream()
		.filter( item -> item.getId() > 10 )
		.forEach( item -> {
			System.out.println(item.getName());
		});
		
		// Paralel Stream Api
		ls
		.parallelStream()
		.filter( item -> item.getId() > 10 )
		.forEach( item -> {
			System.out.println(item.getName());
		});
		
		

	}

}

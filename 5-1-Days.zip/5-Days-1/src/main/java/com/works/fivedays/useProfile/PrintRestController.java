package com.works.fivedays.useProfile;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PrintRestController {
	
	@Autowired PrintService ps;
	
	@GetMapping("/print")
	public Map<String, Object> print( @RequestParam String name) {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("printType", ps.print(name));
		return hm;
	}

}

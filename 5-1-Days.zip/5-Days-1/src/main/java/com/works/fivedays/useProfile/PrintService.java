package com.works.fivedays.useProfile;

import org.springframework.stereotype.Component;

@Component
public interface PrintService {

	String print(String name);
	
}

package com.works.fivedays.useProfile;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("pdf")
public class PdfPrintService implements PrintService {

	@Override
	public String print(String name) {
		return 	"PDF Print " + name;
	}

}

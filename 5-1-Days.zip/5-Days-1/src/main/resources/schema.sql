DROP TABLE IF EXISTS city;
create table if not exists city (cid integer identity not null primary key, name varchar not null); 
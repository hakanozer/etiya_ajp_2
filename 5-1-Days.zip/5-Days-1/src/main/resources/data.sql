insert into city ( name ) values ('Ankara');
insert into city ( name ) values ('İstanbul');
insert into city ( name ) values ('Bursa');
insert into city ( name ) values ('İzmir');
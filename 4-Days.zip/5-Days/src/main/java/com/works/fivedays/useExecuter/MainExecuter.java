package com.works.fivedays.useExecuter;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainExecuter {

	public static void main(String[] args) {
		
		Action ac1 = new Action(1, 10);
		Action ac2 = new Action(10, 20);
		Action ac3 = new Action(20, 30);
		Action ac4 = new Action(30, 40);
		Action ac5 = new Action(40, 50);
		
		Runnable[] actions = { ac1, ac2, ac3, ac4, ac5 };
		ExecutorService executorService = Executors.newFixedThreadPool(actions.length);
		System.out.println("Threads Start");
		for (Runnable item : actions) {
			executorService.execute(item);
		}
		executorService.shutdown();
		while(!executorService.isTerminated()) {}
		System.out.println("Threads Finish");
		
	}

}

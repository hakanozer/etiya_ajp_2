package com.works.fivedays.useHibernate;

import java.util.List;

public class MainHibernate {

	public static void main(String[] args) {
		
		DBUtil db = new DBUtil();
		
		// insert
		/*
		Note note = new Note();
		note.setNtitle("Pazar Kahvaltısı");
		note.setNdesc("Evde Kahvaltı");
		int nid = db.noteInsert(note);
		System.out.println(nid);
		*/
		
		/*
		Note note = db.noteSingle(2);
		System.out.println(note.getNdesc());
		*/
		
		//db.noteSingleDelete(1);
		
		/*
		Note note = new Note();
		note.setNid(2);
		note.setNtitle("Cuma Kahvaltısı");
		note.setNdesc("Cuma Evde Kahvaltı");
		db.noteSingleUpdate(note);
		*/
		
		
		List<Note> ls = db.noteList();
		for (Note item : ls) {
			System.out.println(item.getNtitle());
		}
		
		
		

	}

}

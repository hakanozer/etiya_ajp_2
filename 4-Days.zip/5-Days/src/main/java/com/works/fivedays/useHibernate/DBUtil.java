package com.works.fivedays.useHibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class DBUtil {

	SessionFactory sf = NewHibernateUtil.getSessionFactory();
	
	
	// Note insert
	public int noteInsert( Note note ) {
		
		Session sesi = sf.openSession();
		Transaction tr = sesi.beginTransaction();

		int nid = (int) sesi.save(note);
		tr.commit();
		
		return nid;
	}
	
	
	// Note List
	@SuppressWarnings("unchecked")
	public List<Note> noteList() {
		Session sesi = sf.openSession();
		return sesi
				.createQuery("from Note")
				.setMaxResults(10)
				.list();
	}
	
	
	// Note single item
	public Note noteSingle( int nid ) {
		Session sesi = sf.openSession();
		Note note = sesi.load(Note.class, nid);
		return note;
	}
	
	// Note single delete
	public void noteSingleDelete( int nid ) {
		Session sesi = sf.openSession();
		Transaction tr = sesi.beginTransaction();
		Note note = sesi.load(Note.class, nid);
		sesi.delete(note);
		tr.commit();
	}
	
	// Note single update
	public void noteSingleUpdate( Note note ) {
		Session sesi = sf.openSession();
		Transaction tr = sesi.beginTransaction();
		sesi.update(note);
		tr.commit();
	}
	
	
}

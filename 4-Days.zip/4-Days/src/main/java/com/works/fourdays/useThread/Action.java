package com.works.fourdays.useThread;

public class Action implements Runnable {
	
	String data = "";
	public Action(String data) {
		this.data = data;
	}

	int i = 0;
	@Override
	public void run() {
		try {
			for(;;) {
				System.out.println("Run Call : " + data + " i : " + i);
				Thread.sleep(1000);
				
				if (data.equals("A") && i == 10) {
					break;
				}
				
				if (data.equals("B") && i == 20) {
					break;
				}
				
				i++;
			}
		} catch (Exception e) {
			
		}
		
		
	}

}

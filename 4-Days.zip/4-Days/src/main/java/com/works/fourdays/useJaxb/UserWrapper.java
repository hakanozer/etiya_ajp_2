package com.works.fourdays.useJaxb;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "rootUser")
public class UserWrapper {

	private List<User> ls;

	@XmlElement(name = "user")
	public List<User> getLs() {
		return ls;
	}

	public void setLs(List<User> ls) {
		this.ls = ls;
	}
	
	
	
}

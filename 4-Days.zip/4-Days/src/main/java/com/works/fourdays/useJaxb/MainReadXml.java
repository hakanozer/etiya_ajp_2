package com.works.fourdays.useJaxb;

import java.io.File;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

public class MainReadXml {

	public static void main(String[] args) {
		
		try {
			
			File f = new File("userService.xml");
			JAXBContext context = JAXBContext.newInstance(UserWrapper.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			UserWrapper userWrapper = (UserWrapper) unmarshaller.unmarshal(f);
			List<User> ls = userWrapper.getLs();
			ls.forEach(item -> {
				System.out.println(item.getName() + " " + item.getSec().getTitle());
			});
			
		} catch (Exception e) {
			
		}
		

	}

}

package com.works.fourdays.useThread;

import java.util.concurrent.CompletableFuture;

public class UseCompletable {

	public static void main(String[] args) {
		
		CompletableFuture<Void> ft1 = CompletableFuture.runAsync( () -> {
			for (int i = 0; i < 30; i++) {
				try {
					System.out.println("ft1 Call - i : " + i);
					Thread.sleep(500);
				} catch (Exception e) {
					System.err.println("ft1 error " + e);
				}
			}
		});
		
		
		CompletableFuture<Void> ft2 = CompletableFuture.runAsync( () -> {
			for (int i = 0; i < 20; i++) {
				try {
					System.out.println("ft2 Call - i : " + i);
					Thread.sleep(500);
				} catch (Exception e) {
					System.err.println("ft2 error " + e);
				}
			}
		});
		
		CompletableFuture<Void> allOff = CompletableFuture.allOf(ft1, ft2);
		System.out.println("All Thread Run Call");
		allOff.join();
		System.out.println("All Thread Finish");

	}

}

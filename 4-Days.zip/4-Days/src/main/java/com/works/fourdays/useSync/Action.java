package com.works.fourdays.useSync;

public class Action extends Thread {

	private Customer customer;
	private String name;
	private double count;

	public Action(Customer customer, String name, double count) {
		//System.out.println(name);
		this.customer = customer;
		this.name = name;
		this.count = count;
	}


	@Override
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			System.err.println("run error : " + e);
		}
		customer.minus(name, count);
	}
	
}

package com.works.fourdays.useThread;

public class UseMainThread {

	public static void main(String[] args) {
		
		
		Action ac1 = new Action("A");
		Thread th1 = new Thread(ac1);
		th1.start();
		
		Action ac2 = new Action("B");
		Thread th2 = new Thread(ac2);
		th2.start();
		
		// java 8 lambda -> thread
		Runnable rn = () -> {
			System.out.println("Lambda Thread Using");
		};
		new Thread(rn).start();

		System.out.println("Main Thread Call");
		int a = 10;
	}

}

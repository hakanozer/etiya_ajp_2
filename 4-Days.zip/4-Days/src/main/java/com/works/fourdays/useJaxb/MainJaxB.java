package com.works.fourdays.useJaxb;

import java.io.File;
import java.io.FileWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class MainJaxB {

	public static void main(String[] args) {
		
		try {
			
			UserResult uResult = new UserResult();
			UserWrapper wrapper = new UserWrapper();
			wrapper.setLs(uResult.result());
			
			JAXBContext context = JAXBContext.newInstance(UserWrapper.class);
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.marshal(wrapper, System.out);
			
			File f = new File("userService.xml");
			FileWriter fileWriter = new FileWriter(f);
			marshaller.marshal(wrapper, fileWriter);
			
			
		} catch (Exception e) {
			
		}

		
		
	}
	
	

}

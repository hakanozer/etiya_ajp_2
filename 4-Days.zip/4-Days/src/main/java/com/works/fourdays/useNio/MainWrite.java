package com.works.fourdays.useNio;

import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class MainWrite {

	public static void main(String[] args) {
		
		
		try {
			System.lineSeparator();
			byte[] source = "Merhaba Java\r\nSQL".getBytes();
			RandomAccessFile accessFile = new RandomAccessFile("sample.txt", "rw");
			FileChannel channel = accessFile.getChannel();
			ByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, source.length);
			buffer.put(source);
			channel.write(buffer);
			
			channel.close();
			accessFile.close();
			
		} catch (Exception e) {
			System.err.println("Error : " + e);
		}
		

	}

}

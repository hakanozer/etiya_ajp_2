package com.works.fourdays.useNio;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Scanner;

public class MainRead {

	public static void main(String[] args) {
		
		try {
			FileInputStream fileInputStream = new FileInputStream("sample.txt");
			FileChannel channel = fileInputStream.getChannel();
			long size = channel.size();
			ByteBuffer buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0L, size);
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < size; i++) {
				sb.append((char) buffer.get());
				//System.out.println( (char) buffer.get() );
			}
			System.out.println(sb.toString());
			channel.close();
			fileInputStream.close();
			
			Scanner read = new Scanner(sb.toString());
			while(read.hasNext()) {
				String line = read.nextLine();
				System.out.println("line : " + line);
			}
			
		} catch (Exception e) {
			System.err.println("Error : " + e);
		}

	}

}

package com.works.fourdays.useSync;

public class MainCall {

	public static void main(String[] args) {
		
		Customer customer = new Customer(1000);
		Action ac1 = new Action(customer, "Thread-1", 100);
		Action ac2 = new Action(customer, "Thread-2", 50);
		Action ac3 = new Action(customer, "Thread-3", 10);
		Action ac4 = new Action(customer, "Thread-4", 400);
		Action ac5 = new Action(customer, "Thread-5", 20);
		
		/*
		ac1.start();
		ac2.start();
		ac3.start();
		ac4.start();
		ac5.start();
		*/
		
		/*
		try {
			ac1.start();
			ac1.join();
			ac2.start();
			ac2.join();
			ac3.start();
			ac3.join();
			ac4.start();
			ac4.join();
			ac5.start();
			ac5.join();
		} catch (Exception e) {
		}
		*/
		
		Runnable rn = () -> {
			try {
				ac1.start();
				ac1.join();
				ac2.start();
				ac2.join();
				ac3.start();
				ac3.join();
				ac4.start();
				ac4.join();
				ac5.start();
				ac5.join();
			} catch (Exception e) {
			}
		};
		new Thread(rn).start();
		
		System.out.println("Main Thread Call");

	}

}

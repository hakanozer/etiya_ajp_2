package com.works.fourdays.useJaxb;

import java.util.ArrayList;
import java.util.List;

public class UserResult {
	
	public List<User> result() {
		List<User> ls = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			Section sc = new Section("Section - " + i, i * 5);
			User us = new User(i*2, "Name : " + i, "Surname : " + i , "mail@mail.com" , sc);
			ls.add(us);
		}
		return ls;
	}
	
	
	public void call() throws Exception {
		String stNum = "30a";
		int cint = Integer.parseInt(stNum);
		System.out.println(cint);
	}

}

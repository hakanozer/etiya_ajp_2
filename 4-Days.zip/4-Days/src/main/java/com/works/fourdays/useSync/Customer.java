package com.works.fourdays.useSync;

public class Customer {
	
	private double number;
	
	public Customer(double number) {
		this.number = number;
	}
	
	public synchronized void minus( String name, double count ) {
		this.number -= count;
		System.out.println(name + " " + count + " " + this.number);
	}

}

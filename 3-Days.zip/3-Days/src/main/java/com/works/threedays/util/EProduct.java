package com.works.threedays.util;

public enum EProduct {
	status, message, result, news;
}

package com.works.threedays.restcontrollers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.works.threedays.models.Student;
import com.works.threedays.repositories.StudentRepository;
import com.works.threedays.util.REnum;

@RestController
@RequestMapping("/student")
public class StudentRestController {
	
	@Autowired StudentRepository srepo;
	
	// Student Insert
	@PostMapping("/studentInsert")
	public Map<REnum, Object> studentInsert( @Valid @RequestBody Student st ) {
		Map<REnum, Object> hm = new LinkedHashMap<>();
		hm.put(REnum.status, true);
		hm.put(REnum.result, srepo.saveAndFlush(st));
		return hm;
	}
	
	
	
	// Custom Error Valid
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<REnum, Object> handelError( MethodArgumentNotValidException ex ) {
		Map<REnum, Object> hm = new LinkedHashMap<>();
		List<HashMap<String, Object>> errors = new ArrayList<>();
		List<ObjectError> ls = ex.getBindingResult().getAllErrors();
		for (ObjectError err : ls) {
			String fiedName = ( (FieldError) err ).getField();
			String message = err.getDefaultMessage();
			HashMap<String, Object> hmError = new LinkedHashMap<>();
			hmError.put("fiedName", fiedName);
			hmError.put("message", message);
			errors.add(hmError);
		}
		hm.put(REnum.errors, errors);
		return hm;
	}
	
	
	
	

}

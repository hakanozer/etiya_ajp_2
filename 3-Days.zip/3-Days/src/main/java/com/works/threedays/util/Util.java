package com.works.threedays.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

public class Util {
	
	
	public static String MD5(String md5) {
	   try {
	        java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
	        byte[] array = md.digest(md5.getBytes());
	        StringBuffer sb = new StringBuffer();
	        for (int i = 0; i < array.length; ++i) {
	          sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
	       }
	        return sb.toString();
	    } catch (java.security.NoSuchAlgorithmException e) {
	    }
	    return null;
	}
	
	
	
	public static void admin( String url ) {
		
		Authentication aut = SecurityContextHolder.getContext().getAuthentication();
		
		Collection<? extends GrantedAuthority> cls = aut.getAuthorities();
		List<String> roles = new ArrayList<>();
		for (GrantedAuthority grantedAuthority : cls) {
			roles.add(grantedAuthority.getAuthority());
		}
		
		String obj = aut.getDetails().toString();
		String session = obj.split(";")[1].replace("SessionId: ", "");
		
		System.out.println(aut.getName() +" - "+ url + " - " + session + " - " + roles);

	}
	
	

}

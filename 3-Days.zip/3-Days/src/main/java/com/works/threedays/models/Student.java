package com.works.threedays.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import lombok.Data;

@Data
@Entity
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@NotNull(message = "Name Not Null")
	@NotEmpty(message = "Name Not Empty")
	@Length(min = 3, max = 30, message = "Min 3, Max 30 Char Length")
	private String name;
	
	@NotNull(message = "Mail Not Null")
	@Email(message = "Mail Format Fail")
	private String mail;
	
	@Range(min = 16, max = 40, message = "Age min 16, Max 40")
	private int age;
	
	@Range(min = 1000, max = 5000, message = "number min 1000, Max 5000")
	private int number;
	
}

package com.works.threedays.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	
	@Autowired DriverManagerDataSource db;
	
	// Action -> sql query call
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth
		.jdbcAuthentication()
		.dataSource(db)
		.usersByUsernameQuery(" select mail, pass, status from admin where mail = ? ")
		.authoritiesByUsernameQuery(" select mail, role from admin where mail = ? ")
		.passwordEncoder( passwordEncoder() );
	}
	
	
	// Action -> Role, Mapping
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http
		.httpBasic()
		.and()
		.authorizeRequests()
		//.antMatchers("/product/**").hasRole("product")
		.antMatchers("/product/**").hasAnyRole("product", "admin")
		.antMatchers("/student/**").hasAnyRole("student", "admin")
		//.antMatchers( "/product/**", "/student/**" ).hasRole("admin")
		.and()
		.csrf().disable()
		.formLogin().disable();
		
		http.headers().frameOptions().disable(); // h2 console using
	}
	
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		PasswordEncoder encode = new PasswordEncoder() {
			
			@Override
			public boolean matches(CharSequence rawPassword, String encodedPassword) {
				return Util.MD5(rawPassword.toString()).equals(encodedPassword);
			}
			
			@Override
			public String encode(CharSequence rawPassword) {
				return Util.MD5(rawPassword.toString());
			}
		};
		
		return encode;
	}
	
	
	
	
}

package com.works.threedays.util;

public enum REnum {
	status, message, result, errors;
}

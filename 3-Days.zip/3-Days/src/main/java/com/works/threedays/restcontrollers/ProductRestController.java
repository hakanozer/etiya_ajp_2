package com.works.threedays.restcontrollers;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.GsonJsonParser;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.works.threedays.models.Article;
import com.works.threedays.models.JsonData;
import com.works.threedays.models.Product;
import com.works.threedays.repositories.ProductRepository;
import com.works.threedays.util.EProduct;
import com.works.threedays.util.Util;


@RestController
@RequestMapping("/product")
public class ProductRestController {

	@Autowired ProductRepository prepo;
	
	@PostMapping("/produducInsert")
	public Map<EProduct, Object> produducInsert( @RequestBody Product pro ) {
		Map<EProduct, Object> hm = new LinkedHashMap<>();
		
		// data insert
		Product pr = prepo.saveAndFlush(pro);
		if (pr == null) {
			hm.put(EProduct.status, false);
			hm.put(EProduct.message, "Insert Fail");
			hm.put(EProduct.result, pr);
		}else {
			hm.put(EProduct.status, true);
			hm.put(EProduct.message, "Insert Success");
			hm.put(EProduct.result, pr);
		}
		
		return hm;
	}
	
	
	@GetMapping("/productList")
	public Map<EProduct, Object> productList() {
		Map<EProduct, Object> hm = new LinkedHashMap<>();
		hm.put(EProduct.status, true);
		hm.put(EProduct.message, "Product List");
		hm.put(EProduct.result, prepo.findAll());
		hm.put(EProduct.news, newsResult());
		return hm;
	}
	
	
	public List<Article> newsResult() {
		
		List<Article> ls = new ArrayList<>();
		try {
			
			String url = "http://newsapi.org/v2/top-headlines?sources=google-news-in&apiKey=38a9e086f10b445faabb4461c4aa71f8";
			RestTemplate restTemplate = new RestTemplate();
			String stData =  restTemplate.getForObject(url, String.class);
			
			Gson gson = new Gson();
			JsonData data = gson.fromJson(stData, JsonData.class);
			
			ls = data.getArticles();
			for (Article item : ls) {
				System.out.println(item.getTitle());
			}
			
		} catch (Exception e) {
			System.err.println("News Error : " + e);
		}
		return ls;
	}
	
	
	@GetMapping("/productSingle")
	public Map<EProduct, Object> productSingle( @RequestBody Product pro ) {
		Map<EProduct, Object> hm = new LinkedHashMap<>();
		
		hm.put(EProduct.status, false);
		hm.put(EProduct.message, "Product Single Fail");
		hm.put(EProduct.result, null);
		
		Optional<Product> pr = prepo.findById(pro.getPid());
		pr.ifPresent(item -> {
			hm.put(EProduct.status, true);
			hm.put(EProduct.message, "Product Single");
			hm.put(EProduct.result, item);
		});
		
		return hm;
	}
	
	//@RequestMapping(name = "/productUpdate", method = RequestMethod.PUT)
	@PutMapping("/productUpdate")
	public Map<EProduct, Object> productUpdate( @RequestBody Product pro ) { 
		Map<EProduct, Object> hm = new LinkedHashMap<>();
		Product pr = prepo.saveAndFlush(pro);
		if (pr == null) {
			hm.put(EProduct.status, false);
			hm.put(EProduct.message, "Update Fail");
			hm.put(EProduct.result, null);
		}else {
			hm.put(EProduct.status, true);
			hm.put(EProduct.message, "Update Success");
			hm.put(EProduct.result, pr);
		}
		return hm;
	}
	
	
	@DeleteMapping("/productDelete")
	public Map<EProduct, Object> productDelete( @RequestBody Product pro ) {
		Map<EProduct, Object> hm = new LinkedHashMap<>();
		try {
			prepo.deleteById(pro.getPid());
			hm.put(EProduct.status, true);
			hm.put(EProduct.message, "Delete Success");
			hm.put(EProduct.result, pro.getPid());
		} catch (Exception e) {
			hm.put(EProduct.status, false);
			hm.put(EProduct.message, "Delete Fail");
			hm.put(EProduct.result, null);
		}
		return hm;
	}
	
	
	@GetMapping("/productPrice")
	public Map<EProduct, Object> productPrice( @RequestBody Product pro ) {
		Map<EProduct, Object> hm = new LinkedHashMap<>();
		hm.put(EProduct.status, true);
		hm.put(EProduct.message, "Search Success");
		hm.put(EProduct.result, prepo.findPriceProduct(pro.getPrice()));
		return hm;
	}
	
	
	@GetMapping("/productTitle")
	public Map<EProduct, Object> productTitle( @RequestBody Product pro ) {
		Map<EProduct, Object> hm = new LinkedHashMap<>();
		hm.put(EProduct.status, true);
		hm.put(EProduct.message, "Search Success");
		
		Sort sort = Sort.by(Sort.Direction.ASC, "price");
		List<Product> ls = prepo.findAll(sort);
		hm.put(EProduct.result, ls);
		
		//hm.put(EProduct.result, prepo.findTitleProduct(pro.getTitle()) );
		return hm;
	}
	
}

package com.works.twodays.util;

public enum EUser {
	status, message, result;
}

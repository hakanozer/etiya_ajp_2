package com.works.twodays.restcontrollers;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.works.twodays.util.EUser;
import com.works.twodays.util.UserPro;

@RestController
public class UserRestController {
	
	public UserRestController() {
		System.out.println("UserRestController call");
	}
	
	@PostMapping("/userInsert")
	public Map<EUser, Object> userInsert( 
			@RequestParam(name = "name") String namex,
			@RequestParam String mail
			) {
		Map<EUser, Object> hm = new LinkedHashMap<>();
		hm.put(EUser.status, true);
		hm.put(EUser.message, "Info Message");
		hm.put(EUser.result, namex + " - " + mail);
		return hm;
	}
	
	
	@PostMapping("/userInsertObj")
	public Map<EUser, Object> userInsertObj( UserPro upro ) {
		Map<EUser, Object> hm = new LinkedHashMap<>();
		hm.put(EUser.status, true);
		hm.put(EUser.message, "Info Message");
		hm.put(EUser.result, upro.getName() + " - " + upro.getMail());
		return hm;
	}
	

}

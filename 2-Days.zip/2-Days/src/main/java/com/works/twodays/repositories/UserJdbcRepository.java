package com.works.twodays.repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;

@Repository
public class UserJdbcRepository {
	
	@Autowired DriverManagerDataSource db;

}

package appPack;

import java.util.ArrayList;
import java.util.List;

import inheritance.A;
import inheritance.B;
import inheritance.Base;
import inheritance.C;

public class MainApp {

	public static void main(String[] args) {
		
		A nsa = new A(110);
		B nsb = new B();
		C nsc = new C();
		
		call(nsa);
		call(nsb);
		call(nsc);
		
		//nsa.write();
		//nsb.write();
		//nsc.write();
		
		
		//String st = "Ali";
		//Base nsBase = new A();
		// nsBase ->
		// A
		// Base
		// Base + A
		List<String> ls = new ArrayList<>();

	}
	
	
	public static void call( Base base ) {
		base.write();
	}

}

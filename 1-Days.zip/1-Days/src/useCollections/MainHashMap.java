package useCollections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MainHashMap {

	public static void main(String[] args) {
		
		// HashMap
		HashMap<String, Object> hm = new HashMap<>();
		
		// item add
		hm.put("name", "Ali Bilmem");
		//hm.put("name", "Veli Bilirim");
		hm.put("age", 35);
		hm.put("status", true);
		hm.put("class", "4B");
		
		// single item value
		System.out.println(hm.get("age"));
		
		// single item delete
		hm.remove("age");
		
		
		// Set -> keys
		Set<String> keys = hm.keySet();
		for (String key : keys) {
			System.out.println( key + " : " + hm.get(key) );
		}
		
		// java 8 lambda foreah
		hm.forEach( (key, val) -> {
			System.out.println( key + " : " + val );
		});
		
		
		Set<Entry<String, Object>> enries = hm.entrySet();
		for (Entry<String, Object> entry : enries) {
			System.out.println("key : " + entry.getKey() + " Val : " + entry.getValue());
		}
		
		
		Collection<Object> clo = hm.values();
		clo.forEach( item -> {
			System.out.println("Col " + item + " HashCode : " + item.hashCode());
		});
		
		// all item read
		System.out.println(hm);

		
		List<HashMap<String, Object>> ohm = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			Map<String, Object> hx = new HashMap<>();
			hm.put("name", "Ali " + i);
			hm.put("number", i);
			ohm.add(hm);
		}
		
		
		// Map with Enum
		Map<EProduct, Object> ehm = new HashMap<>();
		ehm.put(EProduct.pid, 101);
		ehm.put(EProduct.ptitle, "iPhoneX");
		ehm.put(EProduct.pprice, 5000);
		ehm.put(EProduct.pdesc, "iPhoneX Desc");
		
		System.out.println(ehm.get(EProduct.ptitle));
		

	}

}

package useCollections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.w3c.dom.ls.LSInput;

public class MainArrayList {

	public static void main(String[] args) {
		
		// ArrayList
		List<String> ls = new ArrayList<>();
		String[] arr = { "İzmir", "Zonguldak", "zonguldak" , "Ankara", "Bursa", "Trabzon" };
		
		// item add
		ls.add("İzmir");
		ls.add("Bursa");
		ls.add("Ankara");
		ls.add("1zonguldak");
		ls.add("zonguldak");
		ls.add("Zonguldak");
		ls.add("Trabzon");
		ls.add("Adana");
		
		
		System.out.println(ls);
		System.out.println(arr);
		
		
		for (String item : ls) {
			System.out.println(item);
		}
		
		/*
		ls.forEach(item -> {
			System.out.println(item);
		});
		*/
		
		List<String> arrayLs = Arrays.asList(arr);
		ArrayList<String> xls = new ArrayList<>();
		xls.addAll(arrayLs);
		xls.add("Adana");
		System.out.println("xls : " + xls);
		Object[] obj = xls.toArray();
		int lgn = arr.length;
		
		// item delete
		ls.remove(0);
		
		// all items delete
		//ls.clear();
		
		// sort
		System.out.println(ls);
		Collections.sort(ls);
		
		// item add index
		ls.add(0, "Gaziantep");
		
		
		boolean status = ls.contains(new String("Adana"));
		System.out.println(status);
		
		int index = ls.indexOf("Adana");
		System.out.println(index);
		
		if ( ls.size() > 0 ) {
			
		}
		if ( !ls.isEmpty() ) {
			
		}
				
		System.out.println(ls);
		
		// Propert with ArrayList
		ResultArrayList list = new ResultArrayList();
		List<User> rls = list.result();
		for (User item : rls) {
			System.out.println(item.getName() + " " + item.getAge());
		}
		
		boolean objStatus = rls.contains( new User() );
		System.out.println(objStatus);
		
	}
	
	public void call( List<String> list ) {
		
	}
	
}

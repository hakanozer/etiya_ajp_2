package useCollections;

import java.util.ArrayList;
import java.util.List;

public class ResultArrayList {
	
	
	public List<User> result() {
		List<User> ls = new ArrayList<>();
		
		for (int i = 0; i < 10; i++) {
			User us = new User();
			us.setAge(i + 10);
			us.setName("Ali -" +i );
			us.setSurname("Bilmem - " +i);
			ls.add(us);
		}
		
		return ls;
	}

}

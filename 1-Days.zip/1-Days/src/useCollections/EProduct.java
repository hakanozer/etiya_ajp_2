package useCollections;

public enum EProduct {

	pid, ptitle, pdesc, pprice;
	
}

package useCollections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class MainHashSet {

	public static void main(String[] args) {
		
		Set<String> hashSet = new HashSet<>();
		hashSet.add("Ali");
		hashSet.add("Ali");
		hashSet.add("Veli");
		hashSet.add("Mehmet");
		hashSet.add("Zehra");

		System.out.println(hashSet);
		
		
		// Linked
		Set<String> linkedSet = new LinkedHashSet<>();
		linkedSet.add("Ali");
		linkedSet.add("Ali");
		linkedSet.add("Veli");
		linkedSet.add("Mehmet");
		linkedSet.add("Zehra");
		
		// items write
		for (String item : linkedSet) {
			System.out.println(item);
		}
		
		Iterator<String> it = linkedSet.iterator();
		while(it.hasNext()) {
			System.out.println("iterator " + it.next());
		}
		
		System.out.println(linkedSet);
		
		
		// treeSet
		Set<String> treeSet = new TreeSet<>();
		treeSet.add("Zehra");
		treeSet.add("Zehra");
		treeSet.add("Zehra");
		treeSet.add("Ahmet");
		treeSet.add("Mehmet");
		treeSet.add("Sinan");
		treeSet.add("Kaan");
		treeSet.add("Ali");
		
		System.out.println("treeSet : " + treeSet);
		
		
	}

}

package useCollections;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainLinkedHashMap {

	public static void main(String[] args) {
		
		
		// LinkedHashMap
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("name", "Ali Bilmem");
		hm.put("age", 35);
		hm.put("status", true);
		hm.put("class", "4B");
		System.out.println(hm);

	}

}

package inheritance;

public class Base {
	
	public Base() {
		System.out.println("Base Call");
	}
	
	public Base( int number ) {
		this.number = number;
	}
	
	public void write() {
		System.out.println("Write Call " + number);
	}
	
	public int number = 10;

}

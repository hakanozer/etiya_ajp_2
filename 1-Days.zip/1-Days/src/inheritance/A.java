package inheritance;

public class A extends Base {
	
	public A() {
		// System.out.println(number); Fail line number
		super(20);
	}
	
	public A(int number) {
		super(number);
	}

	@Override
	public void write() {
		System.out.println("A Write Call " + number);
	}
	
	public String name = "Mehmet";
	
}

package inheritance;

public class C extends Base {

	@Override
	public void write() {
		System.out.println("C Write Call "  + number);
	}
	
}

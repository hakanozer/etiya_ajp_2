package inheritance;

public class B extends Base {
	
	@Override
	public void write() {
		System.out.println("B Write Call "  + number);
	}
}

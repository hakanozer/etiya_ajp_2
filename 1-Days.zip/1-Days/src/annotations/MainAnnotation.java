package annotations;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class MainAnnotation {

	public static void main(String[] args) {
		
		
		Profile pr = new Profile();
		Class<?> prClass = pr.getClass();
		Method[] methods = prClass.getDeclaredMethods();
		for (Method method : methods) {
			System.out.println("method " + method.getName());
			Parameter[] parameters = method.getParameters();
			for (Parameter param : parameters) {
				System.out.println("Param : " + param.getType());
			}
			Annotation[] annotations = method.getAnnotations();
			for (Annotation annotation : annotations) {
				System.out.println(annotation);
			}
		}

	}

}

package annotations;

public enum EUser {

	user, admin, customer;
	
}

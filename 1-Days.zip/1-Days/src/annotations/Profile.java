package annotations;

public class Profile {
	
	@User(id = 10, name = "Ali", surname = "Bilsin", type = EUser.admin)
	public void userName() {
		System.out.println("userName Call");
	}
	
	public void read( String name ) {
		System.out.println("Read Call");
	}

}
